import os
from pathlib import Path
import json

from rdflib import Graph, URIRef, Literal

from nif.annotation import NIFDocument


def read(annotations_path=Path('/home/revenkoa/local_data/LER/ols/01 FerialpraxismitTaschengeld.json'),
         read_limit=-1):
    json_data = json.load(annotations_path.open())
    return json_data

if __name__ == '__main__':
    print(read())