__author__ = 'revenkoa'

from pathlib import Path

from nif.annotation import NIFDocument

def read_and_print(file_path: Path):
    with file_path.open() as f:
        s = f.read()
    print(s)
    d = NIFDocument.parse_rdf(s, format='json-ld')
    # result = d.serialize(format="ttl").decode()
    print(d.annotations)

    _rdf = []
    for ann in d.annotations:
        _rdf += ann
        for au in ann.annotation_units.values():
            _rdf += au

    print(_rdf)


if __name__ == '__main__':
    doc_path = Path('/home/revenkoa/MEGAsync/Projects/LYNX/cybly_decisions/export/export/0a04bfd0-6bd9-45a5-b9cd-dec77c83ab59.de.json')
    read_and_print(doc_path)