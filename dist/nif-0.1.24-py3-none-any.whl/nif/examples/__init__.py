#!/usr/bin/env python

"""

"""

__author__ = 'revenkoa'
__copyright__ = 'Copyright 2015, revenkoa'
__credits__ = ['revenkoa']
__license__ = 'MIT'
__maintainer__ = 'revenkoa'
__email__ = 'artreven@gmail.com'