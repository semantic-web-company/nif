import json, time

from pyld import jsonld

from annotation import *


tic = time.time()
jsonld_path = 'examples/large.json'
with open(jsonld_path) as f:
    j = json.load(f)
tac = time.time()
print(f'loaded, {tac - tic}')

tic = time.time()
nd = NIFDocument.from_json(j)
tac = time.time()
print(tac - tic)
print(len(nd))

# tic = time.time()
# r = jsonld.to_rdf(j)
# print(r)
# tac = time.time()
# print(tac - tic)
# print(len(r))
