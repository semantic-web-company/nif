import calamus.schema, calamus.fields


skos_ns = calamus.fields.Namespace('http://www.w3.org/2004/02/skos/core#')


class A(metaclass=calamus.schema.JsonLDAnnotation):
    def __init__(self, uri=None):
        self.uri = uri or calamus.fields.BlankNodeId()

    uri = calamus.fields.Id()

    class Meta:
        rdf_type = [skos_ns.Concept]


class B(A):
    def __init__(self, obj1, uri=None):
        self.obj1 = obj1
        super(B, self).__init__(uri=uri)

    obj1 = calamus.fields.String(skos_ns.prefLabel)

    class Meta(A.Meta):
        rdf_type = A.Meta.rdf_type

a_uri = 'http://example.com/A'
a = A(uri=a_uri)
assert a.dump()['@id'] == a_uri, f'Serialized URI = {a.dump()["@id"]}, but expected {a_uri}'

b_uri = 'http://example.com/B'
b = B(obj1='something', uri=b_uri)
assert b.dump()['@id'] == b_uri, f'Serialized URI = {b.dump()["@id"]}, but expected {b_uri}'
